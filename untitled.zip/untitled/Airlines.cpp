#include "Airlines.h"
#include <utility>
#pragma once

Airline::Airline(string airlineId, string name, string alias, string iata, string icao, string callsign, string country,
                 char active) {
    Airline_ID = std::move(airlineId);
    Name = std::move(name);
    Alias = std::move(alias);
    IATA = std::move(iata);
    ICAO = std::move(icao);
    Callsign = std::move(callsign);
    Country = std::move(country);
    Active = active;
}
Airline::Airline(){
    Airline_ID = "00000";
};

string Airline::getCallsign() {
    return Callsign;
}

string Airline::getAirline_ID() {
    return Airline_ID;
}

char Airline::getActive() {
    return Active;
}
string Airline::getname(){
    return Name;
}

