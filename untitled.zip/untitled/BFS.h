#include <list>
#include <vector>
#include <queue>
#include "CsvReader.h"
#include "Routes.h"
#include "Airlines.h"
#include "Airport.h"
#include <iostream>
#include "Node.h"
#include <algorithm>
#include "CsvReader.h"

using namespace std;

bool Contains(const std::vector<Node> &list, Node n)
{
    return std::find(list.begin(), list.end(), n) != list.end();
}

bool Contains(const std::list<Node> &list, Node n)
{
    return std::find(list.begin(), list.end(), n) != list.end();
}

int goal_test(Node n, string IATA){

    if(n.getIATA() == IATA){
        return 1;
    }
    return 0;
}

Node BFS(Node state,string destinationiD, vector<Routes>allroutes,vector<Airport>allairports){

    cout<<"running BFS"<<endl;
    list<Node>frontier;
    vector<Node>explored;
    Node *emptynode = new Node();


    if(goal_test(state,CsvReader::IDtoIATA(allairports,destinationiD)) != 0){
        return state;
    }

    frontier.push_back(state);

    
    while(!frontier.empty()){

        explored.push_back(state);
        state = frontier.front();
        frontier.pop_front();
        vector<Routes> routesfromnode= state.getActions();
        Node *parentptrforsearch;
        parentptrforsearch = &state;


        for (Routes route: routesfromnode) {
            Node *child;
            string airportidholder = route.getDest_Airport_ID();
            string iata = CsvReader::IDtoIATA(allairports,airportidholder);
            string city = CsvReader::IATAtoCity(allairports,iata);


//            cout<<parentptrforsearch->getIATA()<<"parent"<<endl;
//            cout<<CsvReader::findAirport(allairports,city).getcity()<<"airport"<<endl;
//            cout<<CsvReader::findAllRouteRecords(allroutes,route.getSrc_Airport_ID())[0].getAirline_ID()<<"routes airline"<<endl;


            child = new Node(parentptrforsearch,
                                  CsvReader::findAirport(allairports,city),
                                  CsvReader::findAllRouteRecords(allroutes,route.getSrc_Airport_ID()));

            cout<<child->getIATA()<<"child iata"<<endl;
            cout<<child->getparent().getIATA()<<"parent iata"<<endl;
            cout<<endl;

            if(!Contains(explored,*child) && !Contains(frontier,*child)){
                cout<<"KAWABANGA"<<endl;
                if(goal_test(*child,CsvReader::IDtoIATA(allairports,destinationiD)) != 0){
                    cout<<"works";
                    return *child;
                }
                else{
                    frontier.push_back(*child);
                }
            }

        }

    }
    return *emptynode;
}


