#include <sstream>
#include <string>
#include <iostream>
#include <fstream>
#include <utility>
#include "Routes.h"
#include "Airlines.h"
#include "Airport.h"
#pragma once
using namespace std;


class CsvReader{
private:
    string uniqueString;

    static Routes routemaker(string routeString);
    static Airline airlinemaker(string);
    static Airport airportmaker(string);

    vector<string> stringsplitterR(string row);
    vector<string> stringsplitterAP(string str);
    vector<string> stringsplitterAR(string str);


public:
    vector<Routes> loadedRoutes;
    vector<Airline> loadedAirline;
    vector<Airport> loadedAirport;
    explicit CsvReader(string filepath, string csvType);

static Airline findAirlineRecord(vector<Airline>, string);
static Airport findAirport(vector<Airport>, string city);
static vector<Routes> findAllRouteRecords(vector<Routes>, string value);
static Routes findUniqueRouteRecord(vector<Routes>, string value);

};

