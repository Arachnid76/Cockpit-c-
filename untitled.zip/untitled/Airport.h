#include <fstream>
#include <string>
#include <sstream>
#include <utility>
#include <vector>
#include <string>
#pragma once

using namespace std;

class Airport {
private:

    string Airport_ID,Name,City,Country,IATA,ICAO;


public:
    Airport(string airportid, string name, string city,string country, string iata, string icao);
    Airport();

    string getAirportID();
    string getcity();
    string getcountry();
    string getICAO();
    string getIATA();

    bool operator==(const Airport &rhs) const;

    bool operator!=(const Airport &rhs) const;

};

