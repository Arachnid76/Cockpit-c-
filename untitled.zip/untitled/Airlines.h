#include <fstream>
#include <string>
#include <sstream>
#include <utility>
#include <vector>
#include <string>
#pragma once
using namespace std;


class Airline {
private:

    string Airline_ID;
    string Name,Alias,IATA,ICAO,Callsign,Country;
    char Active;

public:
    Airline(string airlineId, string name, string alias, string iata, string icao,
            string callsign, string country, char active);
    Airline();

    string getCallsign();
    string getAirline_ID();
    char getActive();
    string getname();

};

