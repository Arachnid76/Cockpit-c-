#include "CustomFileIO.h"
#include "CsvReader.h"
#include <vector>
#include "Node.h"
#pragma once
using namespace std;




int main() {

    auto *inputfile = new CustomFileIO("/Users/arachnid/CLionProjects/untitled/input.txt");

    auto *routes = new CsvReader("/Users/arachnid/Desktop/C++ Project/routes.csv","routes");
    auto *airlines = new CsvReader("/Users/arachnid/Desktop/C++ Project/airlines.csv","airlines");
    auto *airports= new CsvReader("/Users/arachnid/Desktop/C++ Project/airports.csv","airports");

//    cout << idToIATA("1",airports->loadedAirport)<<endl;

    vector<Routes> routesFromUserStart = CsvReader::findAllRouteRecords(routes->loadedRoutes,airports->loadedAirport[2].getAirportID());

    Node *head = new Node();
    Node *test = new Node(head,airports->loadedAirport[2],routesFromUserStart,1);
    cout<<test->getIATA();



//    Airport userAirport = CsvReader::findAirport(airports->loadedAirport,inputfile->startcity);
//    cout<<"The airport Id for "<<inputfile->startcity<< " is "<< userAirport.getAirportID()<< " and the iata code is "<<userAirport.getIATA()<<endl;
//
//    vector<Routes> routesFromUserStart = CsvReader::findAllRouteRecords(routes->loadedRoutes,userAirport.getAirportID());

//    Routes testr = CsvReader::findUniqueRouteRecord(routesFromUserStart, "595");
//    cout<<"the route with the given airline is going to this airport_id: "<<testr.getDest_Airport_ID();
//    Airline testAr = CsvReader::findAirlineRecord(airlines->loadedAirline, testr.getAirline_ID());
//    cout<<testAr.getname()<<endl;




//testing output
//    vector<string> v;
//    v.emplace_back("waguan");
//    v.emplace_back("mi na lyk ya");
//    v.emplace_back("me lav ya");
//    v.emplace_back("pussi");
//
//    inputfile->Makeoutputfile(v);
// it works


    return 0;
}
