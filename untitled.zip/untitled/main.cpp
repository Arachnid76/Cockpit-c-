#include "CustomFileIO.h"
#include "CsvReader.h"
#include "BFS.h"
#include <vector>
#pragma once
using namespace std;

string enterFile(){
    cout << "Please enter the file name: ";
    string name;
    getline (cin, name);
    ifstream ifs(name.c_str());
    if (!ifs) cerr << "can't open input file ", name;
    return name;
}


int main() {

    string Ifilename=  enterFile();
    //"/Users/arachnid/CLionProjects/untitled/input.txt"
    auto *inputfile = new CustomFileIO(Ifilename);

    auto *routes = new CsvReader("/Users/arachnid/Desktop/C++ Project/routes.csv","routes");
    auto *airlines = new CsvReader("/Users/arachnid/Desktop/C++ Project/airlines.csv","airlines");
    auto *airports= new CsvReader("/Users/arachnid/Desktop/C++ Project/airports.csv","airports");

    string srcid = airports->findAirport(airports->loadedAirport,inputfile->startcity).getAirportID();
    string destid = airports->findAirport(airports->loadedAirport,inputfile->stopcity).getAirportID();
    cout<<destid<<" is the destination id of the stop city, so LETS SEARCH"<<endl;

    Node *head = new Node();

    Node *head_ayo = new Node(head,
                              CsvReader::findAirport(airports->loadedAirport,inputfile->startcity),
                              CsvReader::findAllRouteRecords(routes->loadedRoutes,srcid));

    Node hail = BFS(*head_ayo, destid, routes->loadedRoutes, airports->loadedAirport);
    vector<string> ans = hail.solutionpath();
    cout << hail.getIATA();

    for (string s:hail.solutionpath()) {
        cout<<s<<endl;
    }

//    cout << idToIATA("1",airports->loadedAirport)<<endl;

//    vector<Routes> routesFromUserStart = CsvReader::findAllRouteRecords(routes->loadedRoutes,airports->loadedAirport[2].getAirportID());
//    vector<Routes> routestest = CsvReader::findAllRouteRecords(routes->loadedRoutes,airports->loadedAirport[3].getAirportID());
//
//

    // node testing
//    Node *head = new Node();
//    Node *test = new Node(head,airports->loadedAirport[2],routesFromUserStart,1);
//    Node *test2 = new Node(test,airports->loadedAirport[3],routestest,1);
//    for (const string& s:test2->solutionpath()) {
//        cout<<s<<endl;
//    }



//    Airport userAirport = CsvReader::findAirport(airports->loadedAirport,inputfile->startcity);
//    cout<<"The airport Id for "<<inputfile->startcity<< " is "<< userAirport.getAirportID()<< " and the iata code is "<<userAirport.getIATA()<<endl;
//
//    vector<Routes> routesFromUserStart = CsvReader::findAllRouteRecords(routes->loadedRoutes,userAirport.getAirportID());

//    Routes testr = CsvReader::findUniqueRouteRecord(routesFromUserStart, "595");
//    cout<<"the route with the given airline is going to this airport_id: "<<testr.getDest_Airport_ID();
//    Airline testAr = CsvReader::findAirlineRecord(airlines->loadedAirline, testr.getAirline_ID());
//    cout<<testAr.getname()<<endl;




//testing output
//    vector<string> v;
//    v.emplace_back("waguan");
//    v.emplace_back("mi na lyk ya");
//    v.emplace_back("me lav ya");
//    v.emplace_back("pussi");
//
//    inputfile->Makeoutputfile(v);
// it works


    return 0;
}
