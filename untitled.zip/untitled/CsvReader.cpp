//
// Created by Charles Yebuah on 27/11/2022.
//
#pragma once
#include "CsvReader.h"
// takes some vector and turns it into some object
Routes CsvReader::routemaker(string route_as_string){
    Routes *temp;
    vector<string> vect;
    int stops;


    stringstream ss(route_as_string);

    while (ss.good()) {
        string substr;
        getline(ss, substr, ',');
        vect.push_back(substr);
    }
    char arr[vect[7].length() + 1];
    stops = atoi(&arr[0]);


    temp = new Routes(vect[1],vect[3],vect[5],stops);

    return *temp;
}

Airport CsvReader::airportmaker(string airport_as_string){
    Airport *temp;

    vector<string> airport_vect;

    stringstream ss(airport_as_string);

    while (ss.good()) {
        string substr;
        getline(ss, substr, ',');
        airport_vect.push_back(substr);
// airports: Airport ID(1),Name(2),City(3),Country(4),IATA code(5),ICAO(6) don't need the rest

    }
    temp = new Airport(airport_vect[0],airport_vect[1],airport_vect[2],airport_vect[3],airport_vect[4],airport_vect[5]);
    return *temp;


}

Airline CsvReader::airlinemaker(string airline_as_string){
    Airline *temp;

    vector<string> airline_as_str_vect;

    std::stringstream ss(airline_as_string);

    while (ss.good()) {
        string substr;
        getline(ss, substr, ',');
        airline_as_str_vect.push_back(substr);
    }

    char activity = airline_as_str_vect[7][0];

    temp = new Airline(airline_as_str_vect[0], airline_as_str_vect[1], airline_as_str_vect[2], airline_as_str_vect[3], airline_as_str_vect[4],
                       airline_as_str_vect[5], airline_as_str_vect[6], activity);
    return *temp;
}


// writing all 3 types of csv into strings and spliting them into strings in a long vector
vector<string> CsvReader::stringsplitterR(string str){
    vector<string> allrouteinfo;

    string::size_type pos = 0;
    string::size_type prev = 0;

    // using the string size_type instead of int because we don't know how long the vector and its peices can get

    while ((pos = str.find('\n', prev)) != string::npos) {
        allrouteinfo.push_back(str.substr(prev, pos - prev));
        prev = pos + 1;
    }
    allrouteinfo.push_back(str.substr(prev));
//    cout <<"testing all strings to sting vectors in routes "<< allrouteinfo[2]<<endl;
    return allrouteinfo;

}

vector<string> CsvReader::stringsplitterAP(string str){
    vector<string> allairportinfo;


    string::size_type pos = 0;
    string::size_type prev = 0;

    // using the string size_type instead of int because we don't know how long the vector and its peices can get

    while ((pos = str.find('\n', prev)) != string::npos) {
        allairportinfo.push_back(str.substr(prev, pos - prev));
        prev = pos + 1;
    }
    allairportinfo.push_back(str.substr(prev));
//    cout <<"testing all strings to sting vectors in airports "<< allairportinfo[1]<<endl;
    return allairportinfo;

}

vector<string> CsvReader::stringsplitterAR(string str){
    vector<string> allairlineinfo;


    string::size_type pos = 0;
    string::size_type prev = 0;

    // using the string size_type instead of int because we don't know how long the vector and its peices can get

    while ((pos = str.find('\n', prev)) != string::npos) {
        allairlineinfo.push_back(str.substr(prev, pos - prev));
        prev = pos + 1;
    }
    allairlineinfo.push_back(str.substr(prev));

    return allairlineinfo;

}


//general purpose csv reader
CsvReader::CsvReader(string filepath, string csvType) {
    transform(csvType.begin(), csvType.end(), csvType.begin(), ::toupper);
    string *stringform;
    stringform = new string;

    ifstream file;
    file.open(filepath);
    if (file.fail()) {
        cout << "Failed to open input file" << endl;
    }
    else {
        stringstream buffer;
        buffer << file.rdbuf();
        *stringform = buffer.str();

        Airline *tempArl;
        tempArl = new Airline();
        Routes *tempR;
        tempR = new Routes();
        Airport *tempArp;
        tempArp = new Airport();


        if (csvType == "ROUTES") {
            vector<string> allroutes = stringsplitterR(*stringform);

            for(const string& i : allroutes){
                *tempR = routemaker(i);
                loadedRoutes.push_back(*tempR);
            }
        }

        if (csvType == "AIRPORTS") {
            vector<string> allairports = stringsplitterAR(*stringform);

            for(const string& i : allairports){
                *tempArp = airportmaker(i);
                loadedAirport.push_back(*tempArp);
            }

        }
        if (csvType == "AIRLINES") {
            vector<string> allairlines = stringsplitterAR(*stringform);

            for (const string &i: allairlines) {
                *tempArl = airlinemaker(i);
                if (tempArl->getActive()){
                    loadedAirline.push_back(*tempArl);}
                }
            }
        }
    delete stringform;
    }
    Airline CsvReader::findAirlineRecord(vector<Airline> airlines, string value) {
        bool found = false;
        Airline *ans;
        ans = new Airline();
        int count = 0;
        while (!found) {
            if (airlines[count].getAirline_ID() == value) {
                found = true;
                *ans = airlines[count];
                cout << "we found the airline ID for " << airlines[count].getname();
            } else {
                count++;
            }
        }
        return *ans;
    }

    vector<Routes> CsvReader::findAllRouteRecords(vector<Routes> routes, string airportid) {

    vector<Routes> ans;


    for (Routes temproute:routes) {
        if (temproute.getSrc_Airport_ID() == airportid) {
            ans.push_back(temproute);
//            cout << "we found the route for start airport " << airportid << " landing in "<<temproute.getDest_Airport_ID()<<endl
//            << temproute.getAirline_ID()<<endl;
        }
    }
    return ans;
}

    Routes CsvReader::findUniqueRouteRecord(vector<Routes> same_start_vector, string airlineid) {
    Routes *temp;
    temp = new Routes();

    for (Routes record: same_start_vector){
        if (record.getAirline_ID() == airlineid){
            *temp = record;
        }
    }

    return *temp;
}

    Airport CsvReader::findAirport(vector<Airport>allairports, string city) {
        Airport *temp;
        temp = new Airport();

        for (Airport record: allairports){
            if (record.getcity() == city){
                cout<<"we found it!"<<endl;
                *temp = record;
            }

        }

        return *temp;
}
