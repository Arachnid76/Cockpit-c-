//
// Created by Charles Yebuah on 27/11/2022.
//

#include "Routes.h"
#include <utility>
#pragma once
using namespace std;



Routes::Routes(string airlineId, string srcAirportId, string destAirportId, int stops) {
    Airline_ID = std::move(airlineId);
    Src_Airport_ID = std::move(srcAirportId);
    Dest_Airport_ID = std::move(destAirportId);
    Stops = stops;

}
Routes::Routes() {
    Airline_ID = "0";
    Src_Airport_ID = "0";
    Dest_Airport_ID = "0";
    Stops = 0;
}




