#include <sstream>
#include <string>
#include <iostream>
#include <fstream>
#include <utility>
#pragma once

using namespace std;


class Routes{
private:
    string Airline_ID;
    string Src_Airport_ID{};
    string Dest_Airport_ID{};
    int Stops;
    string Equipment;

public:
    Routes(string airlineId, string srcAirportId, string destAirportId, int stops);
    Routes();


    string getAirline_ID() const{return Airline_ID;}
    string getSrc_Airport_ID() const{return Src_Airport_ID;}
    string getDest_Airport_ID() const{return Dest_Airport_ID;}
    int getStops() {return Stops;}


};
