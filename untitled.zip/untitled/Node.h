#include <fstream>
#include <string>
#include <sstream>
#include <utility>
#include <vector>
#include <string>
#include "Airport.h"
#include "Routes.h"
#include "Airlines.h"
#pragma once

using namespace std;

class Node{
public:
    Airport State;
    Node *ParentPtr;
    vector<Routes> Actions;
    int Cost;

    string idToIATA(string someAirportId,vector<Airport> somevector){
        string iata;
        for (Airport t: somevector){
            if(t.getAirportID() == someAirportId)
                iata = t.getIATA();
        }
        return iata;
    }


    Node(Node *parentpointer, Airport state, vector<Routes> actions, int cost) {
        this->ParentPtr = parentpointer;
        this->State = state;
        this->Actions = actions;
        this->Cost = cost;
    }
    Node(){
        ParentPtr = nullptr;
    };

    Node getparent(){
        return *ParentPtr;
    }

    string getIATA(){
        return State.getIATA();
    }

    Airport getstate(){
        return State;
    }

    int getpathcost(){
        return Cost;
    }

    bool operator==(const Node &rhs) const {
        return State == rhs.State &&
               ParentPtr == rhs.ParentPtr &&
               Cost == rhs.Cost;
    }

    bool operator!=(const Node &rhs) const {
        return !(rhs == *this);
    }

    vector<string> solutionpath(){
        vector<string> path;
        string entry;
        int increment;
        while(this->ParentPtr != nullptr){
            Node usingthisnode = this->getparent();
            entry = usingthisnode.getIATA() + " to " + this->getIATA()

        }

        return path;
    }

};