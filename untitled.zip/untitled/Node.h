#include <fstream>
#include <string>
#include <sstream>
#include <utility>
#include <vector>
#include <string>
#include "Airport.h"
#include "Routes.h"
#include "Airlines.h"
#pragma once

using namespace std;

class Node{
public:
    Airport State;
    Node *ParentPtr;
    vector<Routes> Actions;


    static string idToIATA(string someAirportId,vector<Airport> somevector){
        string iata;
        for (Airport t: somevector){
            if(t.getAirportID() == someAirportId)
                iata = t.getIATA();
        }
        return iata;
    }


    Node(Node *parentpointer, Airport state, vector<Routes> actions) {
        this->ParentPtr = parentpointer;
        this->State = state;
        this->Actions = actions;

    }
    Node(const Node &t){
        State = t.State;
        ParentPtr = t.ParentPtr;
        Actions = t.Actions;
    }
    Node(){
        ParentPtr = nullptr;
    }


    Node getparent(){
        return *ParentPtr;
    }

    string getIATA(){
        return State.getIATA();
    }

    Airport getstate(){
        return State;
    }



    const vector<Routes> &getActions() const {
        return Actions;
    }

    bool operator==(const Node &rhs) const {
        return State == rhs.State &&
               ParentPtr == rhs.ParentPtr;
    }

    bool operator!=(const Node &rhs) const {
        return !(rhs == *this);
    }



    vector<string> solutionpath(){
        vector<string> path;
        string entry;
        Node child_current = *this;

        while(child_current.ParentPtr != nullptr){
//            cout << child_current.getparent().getIATA() << endl;
            Node usingthisnode = child_current.getparent();
//            cout<<usingthisnode.getIATA()<<endl;
//            cout<<child_current.getIATA()<<endl;
            Routes UsedRoute;

            for (Routes parentroute: usingthisnode.Actions) {
//                cout<<(child_current.getstate().getAirportID() == parentroute.getDest_Airport_ID())<<endl;
                if (child_current.getstate().getAirportID() == parentroute.getDest_Airport_ID()){
                    UsedRoute = parentroute;
//                    cout<<UsedRoute.getDest_Airport_ID()<<endl;
                }
                else{
//                    cout<<"no route found"<<endl;
                }
            }

            entry = UsedRoute.getAirline_ID()+ ","+usingthisnode.getIATA() + "," + child_current.getIATA();
            path.push_back(entry);

            child_current = usingthisnode;
//           cout<< this->getIATA()<<endl;

        }
        std::reverse(path.begin(), path.end());

        return path;
    }

};