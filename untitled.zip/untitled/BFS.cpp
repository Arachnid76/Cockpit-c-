#include <list>
#include <vector>
#include <queue>
#include "CsvReader.h"
#include "Routes.h"
#include "Airlines.h"
#include "Airport.h"
#include <iostream>

//#include "Graph.h"
using namespace std;

//void BFS(){
//    queue<long int> frontier;
//    list<string> explored;
//    frontier.push(Airport);
//
//    while(frontier.size() > 0){
//        //set node to init node here
//        explored.push_back();
//        if (init.get)
//    }
//}

//class Graph{
//    int v;
//
//public:
//    Graph(int v);
//
//    void addEdge(vector<Airport>,int v);
//    void BFS(int s);
//};
//
//Graph::Graph(int v){
//    this-&gt;v = v;
//    adjList = new list&lt;int&gt;[v];
//}
//
//void Graph::addEdge(vector<Airport>,int v) {
//
//}
//
//void Graph::BFS(int s){
//
//}