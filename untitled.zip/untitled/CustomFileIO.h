#include <fstream>
#include <string>
#include <sstream>
#include <vector>
#pragma once

using namespace std;


class CustomFileIO {
private:
    void stringsplitter(string &);

public:
    string filename;
    string startcity;
    string stopcity;

    string startcountry;
    string stopcountry;

    explicit CustomFileIO(string SomeFileName);
    void Makeoutputfile(vector<string>);

};





