#include "CustomFileIO.h"
#include <string>
#include <sstream>
#include <iostream>
#include <vector>
#pragma once

using namespace std;

//
// Created by Charles Yebuah on 25/11/2022.
//
void CustomFileIO::stringsplitter(string &str){
    vector<string> startstop;
    vector<string> middlechar;


    string::size_type pos = 0;
    string::size_type prev = 0;

    // suing the string size_type instead of int because we don't know how long the vector and its peices can get

    while ((pos = str.find('\n', prev)) != string::npos) {
        startstop.push_back(str.substr(prev, pos - prev));
        prev = pos + 1;
    }
    startstop.push_back(str.substr(prev));

//    for (auto & i : startstop) {
//        cout << i<<endl;
//    }

    int newpos = startstop[0].find(",");
    startcity = startstop[0].substr(0 , newpos);
    startcountry = startstop[0].substr(newpos+1);

    newpos = startstop[1].find(",");
    stopcity = startstop[1].substr(0 , newpos);
    stopcountry = startstop[1].substr(newpos+1);

}

CustomFileIO::CustomFileIO(string SomeFileName) {
    string *stringform;
    stringform = new string ;
    filename = SomeFileName;

    ifstream file;
    file.open(SomeFileName);
    if (file.fail()) {
        cout << "Failed to open input file"<<endl;
    }
    else{
        stringstream buffer;
        buffer<< file.rdbuf();
        *stringform = buffer.str();
        cout << *stringform<<endl;
        stringsplitter(*stringform);

        cout<<"You want to travel from "<< startcity<< " in" << startcountry <<" to "<<stopcity<<" in"<< stopcountry<<"?\n";


    }
    delete stringform;


}

void CustomFileIO::Makeoutputfile(vector<string> Output) {
    //to get the new file name
    string outputfilename = filename + "_output.txt";

    // creating a file
    fstream file;
    file.open(outputfilename,ios_base::out);

    for(int i=0;i<Output.size();i++)
    {
        file<<Output[i]<<endl;
    }

    file.close();
}

