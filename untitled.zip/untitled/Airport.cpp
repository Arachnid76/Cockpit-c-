#include "Airport.h"
#pragma once
#include <utility>

Airport::Airport(string airportid, string name, string city,string country, string iata, string icao){
    Airport_ID =std::move(airportid);
    Name = std::move(name);
    City = std::move(city);
    Country = std::move(country);
    IATA = std::move(iata);
    ICAO = std::move(icao);
}

Airport::Airport() {
}

string Airport::getAirportID() {
    return Airport_ID;
}

string Airport::getcity() {
    return City;
}

string Airport::getcountry() {
    return Country;
}
string Airport::getICAO() {
    return ICAO;
}
string Airport::getIATA() {
    return IATA;
}

bool Airport::operator==(const Airport &rhs) const {
    return Airport_ID == rhs.Airport_ID &&
           Name == rhs.Name &&
           City == rhs.City &&
           Country == rhs.Country &&
           IATA == rhs.IATA;
}

bool Airport::operator!=(const Airport &rhs) const {
    return !(rhs == *this);
}
